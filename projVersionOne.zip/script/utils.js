// export function openPopup(popupElement) {
//     popupElement.classList.add("popup_visible");
//     document.addEventListener('keydown', closeByEsc);
//   };

// export function closePopup(popupElement) {
//     popupElement.classList.remove("popup_visible");
//     document.removeEventListener('keydown', closeByEsc);
//   };

// function closeByEsc(evt) {
//   if (evt.key === 'Escape') {
//     const openedPopup = document.querySelector('.popup_visible');
//     closePopup(openedPopup); 
//     }
// };
